//
//  SayiTahminOyunApp.swift
//  SayiTahminOyun
//
//  Created by Nisanur Kızıltaş on 19.08.2024.
//

import SwiftUI

@main
struct SayiTahminOyunApp: App {
    var body: some Scene {
        WindowGroup {
            Anasayfa()
        }
    }
}
