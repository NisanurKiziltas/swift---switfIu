//
//  sonuc.swift
//  SayiTahminOyun
//
//  Created by Nisanur Kızıltaş on 19.08.2024.
//

import SwiftUI

struct sonucEkranı: View {
    var sonucKontrol = false
    var body: some View {
        
   
        VStack(spacing: 100) {
            
            if sonucKontrol{
                Text("KAZANDINIZ").font(.system(size: 36))
                
                Image("mutlu").resizable().frame(width: 128,height: 128)
            }else {
                Text("KAYBETTİNİZ").font(.system(size: 36))
                
                Image("uzgun").resizable().frame(width: 128,height: 128)
                
            }
            
           
           
        }
    }
}

struct sonuc_Previews: PreviewProvider {
    static var previews: some View {
        sonucEkranı()
    }
}
