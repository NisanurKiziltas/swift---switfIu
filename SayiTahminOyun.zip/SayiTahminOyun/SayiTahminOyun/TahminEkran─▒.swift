//
//  TahminEkranı.swift
//  SayiTahminOyun
//
//  Created by Nisanur Kızıltaş on 19.08.2024.
//

import SwiftUI

struct TahminEkran: View {
    @State private var sonucgecis = false
    @State private var kalanHak = 5
    @State private var yonlendirme = ""
    @State private var tfTahmin = ""
    @State private var rasgelesayi = 0
    @State private var Sonuc = false
    
    var body: some View {
        VStack(spacing: 100) {
            Text("kalan :  \(kalanHak)").font(.system(size: 36)).foregroundColor(.red)
            Text("Yardım :  \(yonlendirme)").font(.system(size: 24))
            
            TextField("tahmin",text: $tfTahmin).textFieldStyle(RoundedBorderTextFieldStyle()).padding(19)
            
            Button("TAHMİN ET "){
               kalanHak = kalanHak - 1
                if let tahmin = Int(tfTahmin){
                    if tahmin == rasgelesayi{
                        sonucgecis = true
                        Sonuc = true
                        return
                        
                    }
                    if tahmin > rasgelesayi{
                        yonlendirme = "azalt"
                        
                    }
                    if tahmin < rasgelesayi{
                        yonlendirme = "arttır"
                        
                    }
                    if kalanHak == 0{
                        sonucgecis = true
                        Sonuc = false
                        
                    }
                }
               
                tfTahmin = ""
                
                
                
                
            }.foregroundColor(.white).frame(width: 250,height: 58).background(.blue).cornerRadius(90)
           
        }.navigationDestination(isPresented: $sonucgecis){
            sonucEkranı(sonucKontrol:Sonuc)
        }.onAppear{
            rasgelesayi = Int.random(in: 0...100)
            print("rangele sayı : \(rasgelesayi)")
            
            // arayüz sıfırlama
            kalanHak = 5
            yonlendirme = ""
            tfTahmin = ""
            
        }
}

struct TahminEkran__Previews: PreviewProvider {
    static var previews: some View {
        TahminEkran()
    }
}
    
}
