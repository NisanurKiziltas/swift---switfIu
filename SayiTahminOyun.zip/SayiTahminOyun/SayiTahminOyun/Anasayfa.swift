//
//  ContentView.swift
//  SayiTahminOyun
//
//  Created by Nisanur Kızıltaş on 19.08.2024.
//

import SwiftUI

struct Anasayfa: View {
    @State private var tahminekrangecis = false
    var body: some View {
        NavigationStack {
            VStack(spacing: 100) {
                Text("TAHMİN OYUNU").font(.system(size: 36))
                Image("zar").resizable().frame(width: 128,height: 128)
                Button("oyuna başla"){
                    tahminekrangecis = true
                }.foregroundColor(.white).frame(width: 250,height: 58).background(.blue).cornerRadius(90)
               
            }.navigationDestination(isPresented: $tahminekrangecis){
                TahminEkran()
            }
        }
    
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        Anasayfa()
    }
}
